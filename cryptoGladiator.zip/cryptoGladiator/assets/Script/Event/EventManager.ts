/*
*Create By George 2018-11-08 05:47:16
*/
const { ccclass, property } = cc._decorator;
export enum EventType {

    SCENE_LOAD_START,

    SCENE_LOAD_END,

    IAP_EVENT,

    NETWORK_ERROR,

    WINDOW_RESIZE,

    CHARACTER_DEAD,

    CHARACTER_WEAR_ALL_EQUIP,
    CHARACTER_WEAR_EQUIP,
    CHARACTER_TAKEOFF_EQUIP,
    CHARACTER_SHOW_USELESS_EQUIP,
    DEBUG_INFO,
    //更新血条
    UPDATE_HPBAR,
    //生成一波怪
    CREATE_NEXT_MONSTER,
    //角色等级属性
    CHARACTER_LEVEL_ATTRIBUTE,
    //角色等级提升
    CHARACTER_LEVEL_UPGRADE,
    //语言切换
    LANGUAGE_CHANGE,
    //角斗士属性发生改变
    GLADIATORINFO_CHANGE,
    //游戏结束
    GAME_OVER,
    //装备购买
    EQUIPMENT_CHANGE,
    //角斗士购买
    GLADIATUS_CHANGE,
    //更新技能板
    UPDATE_SKILLS,
    //清空技能
    CLEAR_SKILLS,
    //自动释放技能开启
    OPEN_AUTO_SKILLS,
    //暂停技能按钮时间
    PAUSE_SKILLS_TIMER,
    //恢复技能按钮时间
    RESUME_SKILLS_TIMER,
    //金币改变
    COIN_CHANGE,
    //波次改变
    GROUPNUM_CHANGE,
    //领取任务奖励成功
    GET_TASK_REWARDS_SUCCESS,
    //链上装备改变
    CHAINEQUIP_CHANGE,
    //链上角斗士改变
    CHAINGLADIATUS_CHANGE,
    //更新钱包金额
    UPDATE_WALLET_AMOUNT,
}

@ccclass
export class EventManager extends cc.Component {
    public static Instance: EventManager;

    public onLoad() {
        EventManager.Instance = this;
    }

    public addListener(eventType: EventType, eventHandler: (event: any) => any, target: any) {
        this.node.on(eventType + "", eventHandler, target);
    }
    public removeListener(eventType: EventType, eventHandler: (event: any) => any, target: any) {
        this.node.off(eventType + "", eventHandler, target);
    }
    public emit(eventType: EventType, msg?: any) {
        if (this.node.hasEventListener(eventType + "")) {
            this.node.emit(eventType + "", msg);
        }
    }
    public addListenerNetwork(name: string, eventHandler: Function, target?: any) {
        this.node.on(name, eventHandler, target);
    }
    public removeListenerNetwork(name: string, eventHandler: Function, target?: any) {
        this.node.off(name, eventHandler, target);
    }
    public emitNetwork(name: string, msg?: any) {
        if (this.node.hasEventListener(name)) {
            this.node.emit(name, msg);
        } else {
            cc.warn("Unhandle EventType->", name);
        }
    }
}