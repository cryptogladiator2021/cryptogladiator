/*
*Create By George 2018-10-25 09:27:57
*/
import { TimeManager } from "./TimeManager";
import { Dictionary } from "../Util/Utility";
import { GameData } from "../Tables/GameData";
import { ClaimTimerData } from "../Tables/ClaimTimerData";

const {ccclass, property} = cc._decorator;

export class ClaimTimerObject{
    private keyTimeStamp:string;
    private keyContinuePeriods:string;
    private keyTriggerTimes:string;

    private lastTimeStamp:number;
    private timerName:string;
    private period:number;
    private startAvailable:boolean;
    private isReady:boolean = false;
    get IsReady(){
        return this.isReady;
    }
    /// <summary>
    /// 使用了多少次
    /// </summary>
    private triggerTimes:number;
    get TriggerTimes(){
        return this.triggerTimes;
    }
    /// <summary>
    /// 连续用了多少次
    /// </summary>
    private continuePeriods:number;
    get ContinuePeriods(){
        return this.continuePeriods;
    }

    constructor(name:string,period:number,startAvailable:boolean){
        this.timerName = name;
        this.period = period;
        this.startAvailable = startAvailable;
        this.keyTimeStamp = this.timerName+"_timestamp";
        this.keyContinuePeriods = this.timerName+"_continue_periods";
        this.keyTriggerTimes = this.timerName+"_trigger_times";
        
        let currentTimeStamp:number = TimeManager.Instance.TimeStamp;
        if(cc.sys.localStorage.getItem(this.keyTimeStamp)==null){
            this.lastTimeStamp = this.startAvailable?currentTimeStamp-this.period:currentTimeStamp;
            cc.sys.localStorage.setItem(this.keyTimeStamp,this.lastTimeStamp);
        }else{
            this.lastTimeStamp = cc.sys.localStorage.getItem(this.keyTimeStamp);
        }
        let cp:number = cc.sys.localStorage.getItem(this.keyContinuePeriods);
        if(cp==null||cp==undefined){
            this.continuePeriods = 0;
            cc.sys.localStorage.setItem(this.keyContinuePeriods,0);
        }else{
            this.continuePeriods = +cp;
        }

        let tr:number = cc.sys.localStorage.getItem(this.keyTriggerTimes);
        if(tr==null||tr==undefined){
            this.triggerTimes = 0;
            cc.sys.localStorage.setItem(this.keyTriggerTimes,0);
        }else{
            this.triggerTimes = +tr;
        }
    }

    public refresh(){
        let currentTimeStamp:number = TimeManager.Instance.TimeStamp;
        this.lastTimeStamp = cc.sys.localStorage.getItem(this.keyTimeStamp);
        let timeGap = currentTimeStamp-this.lastTimeStamp;
        this.isReady = timeGap>=this.period?true:false;
        if(!this.isReady) return;
        if(timeGap>2*this.period){
            this.continuePeriods = 0;
            cc.sys.localStorage.setItem(this.keyContinuePeriods,0);
        }else{
            let cp:number = cc.sys.localStorage.getItem(this.keyContinuePeriods);
            this.continuePeriods = +cp;
        }
        let tr:number = cc.sys.localStorage.getItem(this.keyTriggerTimes);
        this.triggerTimes = +tr;
    }

    public claim(resetContinuePeriods:boolean=false){
        if(!this.isReady) return;
        this.lastTimeStamp = TimeManager.Instance.TimeStamp;
        cc.sys.localStorage.setItem(this.keyTimeStamp,this.lastTimeStamp);
        this.continuePeriods++;
        this.triggerTimes++;
        cc.sys.localStorage.setItem(this.keyContinuePeriods,this.continuePeriods);
        cc.sys.localStorage.setItem(this.keyTriggerTimes,this.triggerTimes);
    }

    public getTimeToClaim(){
        let currentTimeStamp = TimeManager.Instance.TimeStamp;
        let gap = this.period-(currentTimeStamp-this.lastTimeStamp);
        return gap>0?gap:0;
    }
    /// <summary>
    /// 用于：respin时间，doubleexp时间，
    /// 当用户获得新的时间时，修改period，达到增加倒计时时间目的
    /// </summary>
    public addPeriod(value:number){
        this.period += value;
        GameData.Instance.claimTimerDataDictionary[this.timerName].Period = this.period;
    }
}

export class ClaimTimer{
    private static instance:ClaimTimer =null;

    static get Instance(){
        if(ClaimTimer.instance != null){
            return ClaimTimer.instance;
        }else{
            return ClaimTimer.instance = new ClaimTimer();
      
        }
    }
    private timerDictionary:Dictionary<ClaimTimerObject> = new Dictionary<ClaimTimerObject>();

    private constructor(){}
    
    public init(){
        let timerDataArray:Array<ClaimTimerData> = GameData.Instance.claimTimerDataArray;

        for(let ctod of timerDataArray){
            if(this.timerDictionary.containsKey(ctod.timerName)){
                //console.log("Timer已经被添加，类型："+ctod.timerName);
                continue;
            }
            let startAv = ctod.startAvailable==0?false:true;
            let cto:ClaimTimerObject = new ClaimTimerObject(ctod.timerName,ctod.Period,startAv);
            this.timerDictionary.add(ctod.timerName,cto);
        }
    }

    public getClaimTimerObject(timerName:string):ClaimTimerObject{
        return this.timerDictionary[timerName];
    }
}