import { HttpConnection } from "../Net/HttpConnection";

/*
*Create By George 2018-10-24 20:42:33
*/
const {ccclass, property} = cc._decorator;

class TestReq{
    public UUID:string;
    public Code:string;
    public Data0:string;
}
@ccclass
export class TimeManager extends cc.Component{

    public static Instance:TimeManager;

    private totalTime:number =0;
    /// <summary>
    /// 游戏启动到现在经过的时间
    /// </summary>
    get TotalTime(){
        return this.totalTime;
    }

    private timeStamp:number;

    get TimeStamp(){
        return this.timeStamp+Math.floor(this.totalTime);
    }

    get Time(){
        return this.totalTime;
    }

    public init(timeUrl:string){
        TimeManager.Instance = this;
        if(CC_DEBUG){
            this.timeStamp = Date.parse(new Date().toString())/1000;
        }else{
            return HttpConnection.Instance.sendMsgWithoutToken(timeUrl,'GET').then((t:string)=>{
                if(t!=null){
                    this.timeStamp = +t;
                }else{
                    this.timeStamp = Date.parse(new Date().toString())/1000;
                }
            });
        }
    }

    update(dt:number){
        this.totalTime += dt;
    }
}