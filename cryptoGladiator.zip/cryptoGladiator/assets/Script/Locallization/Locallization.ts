/*
* Created by George on 2018/10/23
*/
import EditBox = cc.EditBox;
import { Dictionary, Utility } from "../Util/Utility";
import { EventManager, EventType } from "../Event/EventManager";

export class Locallization {

    private static instance: Locallization = null;

    static get Instance() {
        if (this.instance != null) {
            return this.instance;
        } else {
            return this.instance = new Locallization();

        }
    }

    private constructor() { }
    private textData_CN: Dictionary<string> = new Dictionary<string>();
    private textData_EN: Dictionary<string> = new Dictionary<string>();
    private isChinese:boolean;
    public GetIsChinese():boolean{
        return this.isChinese;
    }
    public SetIsChinese(value:boolean){
        this.isChinese = value;
        EventManager.Instance.emit(EventType.LANGUAGE_CHANGE,null)
    }
    //初始化,Json存入字典
    public init(CN: string, EN: string) {
        this.textData_CN.clear();
        let jrc = JSON.parse(CN);
        for (var attr in jrc) {
            this.textData_CN.add(attr, jrc[attr]);
        }
        this.textData_EN.clear();
        let jre = JSON.parse(EN);
        for (var attr in jre) {
            this.textData_EN.add(attr, jre[attr]);
        }
        let sysLanguage: string = cc.sys.language;
        switch (sysLanguage) {
            case cc.sys.LANGUAGE_CHINESE:
                this.isChinese = true;
                break;
            // case cc.sys.LANGUAGE_FRENCH:
            //     return 'FR';
            // case cc.sys.LANGUAGE_GERMAN:
            //     return 'GE';
            // case cc.sys.LANGUAGE_ITALIAN:
            //     return 'IT';
            // case cc.sys.LANGUAGE_RUSSIAN:
            //     return 'RU';
            // case cc.sys.LANGUAGE_SPANISH:
            //     return 'SP';
            // case cc.sys.LANGUAGE_PORTUGUESE:
            //     return 'PT';
            // case cc.sys.LANGUAGE_TURKISH:
            //     return 'TK';
            default:
                this.isChinese = false;
                break;
        }
        this.SetIsChinese(false) // todo
    }
    public getLanguage() {
        let sysLanguage: string = cc.sys.language;

        switch (sysLanguage) {
            case cc.sys.LANGUAGE_CHINESE:
                return 'CN';
            // case cc.sys.LANGUAGE_FRENCH:
            //     return 'FR';
            // case cc.sys.LANGUAGE_GERMAN:
            //     return 'GE';
            // case cc.sys.LANGUAGE_ITALIAN:
            //     return 'IT';
            // case cc.sys.LANGUAGE_RUSSIAN:
            //     return 'RU';
            // case cc.sys.LANGUAGE_SPANISH:
            //     return 'SP';
            // case cc.sys.LANGUAGE_PORTUGUESE:
            //     return 'PT';
            // case cc.sys.LANGUAGE_TURKISH:
            //     return 'TK';
            default:
                return 'EN';
        }
    }

    public getText(key: string) {
        if (this.isChinese) {
            if (this.textData_CN.containsKey(key)) {
                return this.textData_CN[key];
            } else {
                return 'undefined:' + key;
            }
        }
        else if (!this.isChinese) {
            if (this.textData_EN.containsKey(key)) {
                return this.textData_EN[key];
            } else {
                return 'undefined:' + key;
            }
        }
        // if (cc.sys.language == cc.sys.LANGUAGE_CHINESE) {
        //     if (this.textData_CN.containsKey(key)) {
        //         return this.textData_CN[key];
        //     } else {
        //         return 'undefined:' + key;
        //     }
        // }
        // else if (cc.sys.language == cc.sys.LANGUAGE_ENGLISH) {
        //     if (this.textData_EN.containsKey(key)) {
        //         return this.textData_EN[key];
        //     } else {
        //         return 'undefined:' + key;
        //     }
        // }
    }
    
}