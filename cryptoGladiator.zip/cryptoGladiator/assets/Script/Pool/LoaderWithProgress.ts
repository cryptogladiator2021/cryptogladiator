
export class LoaderWithProgress{
    private totalModelCount:number = 0;
    private completeModelCount:number = 0;
    private progressCallback:(progress:number)=>void;

    private funcArray:Function[]=[];
    public addMission(missionFunc:(cb:Function)=>any){
        this.funcArray.push(missionFunc);
        this.totalModelCount++;
        return this;
    }

    public async startProcess(progressCallback:(progress:number)=>void){
        this.progressCallback = progressCallback;
        for(let i=0;i<this.funcArray.length;i++){
            await this.funcArray[i](this.onProgress.bind(this));
            this.completeModelCount++;
        }
    }

    private onProgress(progress:number){
        this.progressCallback((this.completeModelCount+progress)/this.totalModelCount);
    }
}