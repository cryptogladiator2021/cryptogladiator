import { Dictionary, Utility } from "../Util/Utility";

/*
*Create By George 2018-12-27 19:41:49
*场景中的资源，采用手动加载释放的策略，场景中不挂任何资源，
资源分两类，动态资源，常驻资源。
1，对于动态资源，进入场景手动加载，切换场景时手动释放。
2，对于常驻资源，需要确保其自身及依赖，不会被动态资源依赖。
模块：
1,加载，释放，缓存资源
2，切换场景时，释放所有需要释放的资源及其依赖
3，加载场景时，可按目录预加载资源
*/
export class ResourceCache {
    private static instance: ResourceCache = null;
    static get Instance() {
        if (ResourceCache.instance == null) {
            ResourceCache.instance = new ResourceCache();
        }
        return ResourceCache.instance;
    }
    private resDictionary: Dictionary<any> = new Dictionary<any>();

    public loadResDir(dir: string, autoRelease?: boolean, progressCallback?: (c: number, t: number) => void) {
        return new Promise((resolve, reject) => {
            cc.loader.loadResDir(dir, progressCallback, (err, res, urls) => {
                if (err) {
                    cc.error(err.message || err);
                } else {
                    for (let i = 0; i < urls.length; i++) {
                        if (autoRelease != null) {
                            res[i]['autoRelease'] = autoRelease;
                        }
                        this.resDictionary.add(urls[i], res[i]);
                    }
                }
                resolve(res);
            });
        });
    }

    public loadRes(url: string, autoRelease?: boolean, progressCallback?: (c: number, t: number) => void) {
        if (url.indexOf("-1") != -1) {
            console.log("----");

        }
        return new Promise((resolve, reject) => {
            if (this.resDictionary.containsKey(url)) {
                resolve(this.resDictionary[url]);
            } else {
                cc.loader.loadRes(url, progressCallback, (err, res) => {
                    if (err) {
                        cc.error(err.message || err);
                        resolve(null);
                    } else {
                        if (autoRelease != null) {
                            res['autoRelease'] = autoRelease;
                        }
                        this.resDictionary.add(url, res);
                        resolve(res);
                    }
                });
            }
        });
    }

    public getRemotePic(url: string, autoRelease?: boolean, progressCallback?: (c: number, t: number) => void) {
        return new Promise((resolve, reject) => {
            if (this.resDictionary.containsKey(url)) {
                resolve(this.resDictionary[url]);
            } else {
                if (url == null || url == "") {
                    resolve(null);
                } else {
                    cc.loader.load({ url: url, type: 'jpg' }, (err, texture) => {
                        if (err) {
                            cc.error(err.message || err);
                            resolve(null);
                        } else {
                            let photoSpriteFrame = new cc.SpriteFrame(texture);
                            if (autoRelease != null) {
                                photoSpriteFrame['autoRelease'] = autoRelease;
                            }
                            this.resDictionary.add(url, photoSpriteFrame);
                            resolve(photoSpriteFrame);
                        }
                    });
                }
            }
        });
    }


    public getRes(url: string) {
        return this.resDictionary[url];
    }

    public clear() {
        let removeKeys: string[] = [];
        let keys = this.resDictionary.keys();
        keys.forEach(e => {
            let autoRelease = this.resDictionary[e]['autoRelease'];
            if (autoRelease == true) {
                let deps = cc.loader.getDependsRecursively(e);
                cc.loader.release(deps);
                removeKeys.push(e);
            }
        });
        removeKeys.forEach(e => {
            this.resDictionary.remove(e);
        });
        cc.sys.garbageCollect();
    }


    //------------------------------------------------------------------------------------------------

    public spriteFrameDir: Dictionary<cc.SpriteFrame> = new Dictionary<cc.SpriteFrame>();
    public sp: cc.SpriteFrame;
    public TextureAssetLoad(progressCallback: (c: number, t: number) => void) {
        return new Promise((resolve, reject) => {
            cc.loader.loadResDir("texture", progressCallback, (err, res, urls) => {
                if (err) {
                    cc.error(err.message || err);
                } else {
                    for (let i = 0; i < urls.length; i++) {
                        this.spriteFrameDir.add(res[i].name, res[i]);
                    }
                }
                resolve(res);
            });
        });


    }

    public spriteAtlasDir: Dictionary<cc.SpriteAtlas> = new Dictionary<cc.SpriteAtlas>();

    public TextureAtlasAssetLoad(progressCallback: (c: number, t: number) => void) {
        return new Promise((resolve, reject) => {
            cc.loader.loadResDir("atlas", cc.SpriteAtlas, progressCallback, (err, res, urls) => {
                if (err) {
                    cc.error(err.message || err);
                } else {
                    for (let i = 0; i < urls.length; i++) {
                        this.spriteAtlasDir.add(res[i].name, res[i]);
                    }
                    //console.log("spriteAtlasDir:",this.spriteAtlasDir);
                }
                resolve(res);
            });
        });

    }
}