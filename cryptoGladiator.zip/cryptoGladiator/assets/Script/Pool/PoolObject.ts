/*
*Create By George 2018-10-27 09:50:26
*/
const {ccclass, property} = cc._decorator;


@ccclass
export class PoolObject extends cc.Component{
    public initOnce(){}
    protected unuse(){}
    protected resue(){}
}