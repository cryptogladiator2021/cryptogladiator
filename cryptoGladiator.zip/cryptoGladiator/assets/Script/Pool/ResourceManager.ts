/*
* Created by George on 2018/10/23
*/
import { DebugHelper } from "../../Helper/DebugHelper";
import { Dictionary, Utility } from "../Util/Utility";
import { PoolObject } from "./PoolObject";
import { ResourceCache } from "./ResourceCache";

const { ccclass, property } = cc._decorator;

@ccclass
export class ResourceManager extends cc.Component {

    public static Instance: ResourceManager;

    private poolDictionary: Dictionary<cc.NodePool> = new Dictionary<cc.NodePool>();

    onLoad() {
        ResourceManager.Instance = this;
    }
    /// <summary>
    /// 从资源路径创建,这些资源仅需要时加载
    /// </summary>
    public async getFromResource(url: string, size: number, autoRelease: boolean = true) {
        let result: cc.Node;
        let pool: cc.NodePool;
        let poolSize = 0;

        //没有这个pool则创建，有这个pool但为空，则加入
        let isContain = this.poolDictionary.containsKey(url);
        if (isContain) {
            pool = this.poolDictionary[url];
            poolSize = this.poolDictionary[url].size();
        }
        if (size > 0 && (!isContain || poolSize <= 0)) {
            if (!isContain) {
                pool = new cc.NodePool(PoolObject)
                pool['autoRelease'] = autoRelease;
                this.poolDictionary.add(url, pool);
            } else {
                size = 1;
            }
            let nodePrefab = await ResourceCache.Instance.loadRes(url, autoRelease) as cc.Prefab;
            for (let i: number = 0; i < size; i++) {
                let node: cc.Node = cc.instantiate(nodePrefab);
                let poolObj = node.getComponent(PoolObject);
                if (poolObj != null) {
                    poolObj.initOnce();
                }
                node['poolName'] = url;
                pool.put(node);
            }
        }
        pool = this.poolDictionary[url];
        result = pool.get();
        result.active = true;
        return result;
    }
    /// <summary>
    /// 从已有资源创建
    /// </summary>
    public get(nodeTemplate: any, size: number) {

        let pool: cc.NodePool;

        let poolName: string = nodeTemplate.name;

        let result: cc.Node;

        if (!this.poolDictionary.containsKey(poolName) && size > 0) {
            pool = new cc.NodePool(PoolObject)

            this.poolDictionary.add(poolName, pool);

            for (let i: number = 0; i < size; i++) {
                let node: cc.Node = cc.instantiate(nodeTemplate);
                let poolObj = node.getComponent(PoolObject);
                if (poolObj != null) {
                    poolObj.initOnce();
                }
                node['poolName'] = poolName;
                pool.put(node);
            }
        }

        pool = this.poolDictionary[poolName];

        if (pool.size() > 0) {
            result = pool.get();
        }
        else {
            let node: cc.Node = cc.instantiate(nodeTemplate);
            let poolObj = node.getComponent(PoolObject);
            if (poolObj != null) {
                poolObj.initOnce();
            }
            node['poolName'] = poolName;
            result = node;
        }
        result.active = true;

        return result;
    }

    public return(node: cc.Node) {
        let poolName = node['poolName'];
        let pool: cc.NodePool = this.poolDictionary[poolName];
        if (pool != undefined) {
            pool.put(node);
            node.active = false;
        }
    }

    public clear() {
        let values = this.poolDictionary.values;
        for (let i = 0; i < values.length; i++) {
            let autoRelease = values[i]['autoRelease'];
            if (autoRelease == true) {
                continue;
            }
            values[i].clear();
        }
        this.poolDictionary.clear();
    }


    // public spriteFrameDir:Dictionary<cc.SpriteFrame> = new Dictionary<cc.SpriteFrame>();
    // public  sp:cc.SpriteFrame;
    // private async TextureAssetLoad(){
    //     cc.loader.loadResDir("texture", (err,res,urls)=>{
    //         if(err){
    //             cc.error(err.message || err);
    //         }else{
    //             for(let i=0;i<urls.length;i++){
    //                 this.spriteFrameDir.add(res[i].name,res[i]);
    //             }
    //         }});
    // }
    public GetSpriteFrameByName(spriteName: string): cc.SpriteFrame {
        let spf: cc.SpriteFrame = ResourceCache.Instance.spriteFrameDir[spriteName];
        return spf;
    }

    public GetSpriteAtlasByName(spriteName: string): cc.SpriteAtlas {
        let spa: cc.SpriteAtlas = ResourceCache.Instance.spriteAtlasDir[spriteName];
        //console.log("spa:",spa);
        return spa;
    }
}