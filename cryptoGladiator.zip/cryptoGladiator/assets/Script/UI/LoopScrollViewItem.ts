/*
*Create By George 2018-11-09 13:57:24
*/
const {ccclass, property} = cc._decorator;


@ccclass
export class LoopScrollViewItem extends cc.Component{
    protected id:number;
    onLoad(){
        this.initOnce();
    }
    get Id(){
        return this.id;
    }
    protected initOnce(){

    }
    public updateItem(index:number){
        this.id = index;
    }
}