/*
* Created by George on 2018/10/21
*/

import {UIType} from "./UIType";

export class BaseContext {
    private viewType:UIType;

    public closeCallback:Function;

    get ViewType(){
        return this.viewType;
    }

    get CloseCallback(){
        return this.closeCallback;
    }

    constructor(viewType:UIType,closeCallback?:Function){

        this.viewType = viewType;

        this.closeCallback = closeCallback;
    }
}