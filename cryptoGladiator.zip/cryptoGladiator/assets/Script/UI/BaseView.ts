/*
* Created by George on 2018/10/21
*/
import {BaseContext} from "./BaseContext";
import { ContextManager } from "./ContextManager";
import { AutoScaler } from "./AutoScaler";
import { Utility } from "../Util/Utility";

const {ccclass, property} = cc._decorator;

@ccclass
export class BaseView extends cc.Component {

    private isInit:boolean = false;
    
    private mask:cc.Node;
    @property(cc.Boolean)
    protected autoResize:boolean = true;
    @property(cc.Boolean)
    protected touchMaskClose:boolean = false;
    @property(cc.Button)
    protected closeButton:cc.Button = null;
/// <summary>
/// 回调参数
/// </summary>
    protected callbackMsg:any;

    onLoad(){
        if(this.autoResize){
            this.node.addComponent(AutoScaler);
        }
    }
    public onEnter(context:BaseContext){
        if(!this.isInit){
            this.initOnce(context);
            this.isInit =true;
            this.mask = this.node.getChildByName('mask');
            if(this.mask!=null){
                this.mask.on(cc.Node.EventType.TOUCH_START,function(event:Event){
                    if(this.touchMaskClose&&event.target==this.mask){
                        ContextManager.Instance.pop();
                    }
                    event.stopPropagation();
                }.bind(this));
                this.mask.on(cc.Node.EventType.MOUSE_MOVE,function(event:Event){
                    event.stopPropagation();
                });
            }
            if(this.closeButton!=null){
                Utility.safeButton(this.closeButton,()=>{
                    ContextManager.Instance.pop();
                },this);
            }
        }
    }

    public onExit(context:BaseContext){
        
        if(context.CloseCallback!=null){
            context.CloseCallback(this.callbackMsg);
        }
        if(this.mask!=null){
            this.mask.off(cc.Node.EventType.TOUCH_START,function(event:Event){
                event.stopPropagation();
            });
            this.mask.off(cc.Node.EventType.MOUSE_MOVE,function(event:Event){
                event.stopPropagation();
            });
        }
        if(this.closeButton!=null){
            this.closeButton.node.off('click',function(event:Event){
                ContextManager.Instance.pop();
            });
        }
    }

    public onPause(context:BaseContext){
        this.node.active = false;
    }

    public onResume(context:BaseContext){
        this.node.active = true;
    }

    public initOnce(context:BaseContext){

    }
}