/*
* Created by George on 2018/10/20
*/
import {Dictionary, Utility} from "../Util/Utility";
import {UIType} from "./UIType";
import {ContextManager} from "./ContextManager";
import { ResourceCache} from "../Pool/ResourceCache";
import { EventManager, EventType } from "../Event/EventManager";


export class UIManager {

    private static instance:UIManager = null;

    static get Instance(){
        if(this.instance != null){
            return this.instance;
        }else{
            return this.instance = new UIManager();
        }
    }

    private constructor(){
        EventManager.Instance.addListener(EventType.SCENE_LOAD_END,this.onSceneLoadEnd,this);
    }
    /// <summary>
    /// path+id -> node
    /// </summary>
    private uiDictionary:Dictionary<cc.Node> = new Dictionary();

    private canvas:cc.Node;

    get Canvas(){
        return this.canvas;
    }

    private underUIRootNode:cc.Node;
    get UnderUIRootNode(){
        return this.underUIRootNode;
    }

    public getSingleUISync(uiType:UIType){
        let key = uiType.Identifier;
        let node:cc.Node = null;
        if(this.uiDictionary.containsKey(key)&&cc.isValid(this.uiDictionary[key],true)){
            node = this.uiDictionary[key];
        }else{
            let prefab = uiType.Prefab==null? ResourceCache.Instance.getRes(uiType.Path):uiType.Prefab;
            if(prefab==null){
                return null;
            }
            node = cc.instantiate(prefab);
            node.setParent(this.canvas);
            node.name = uiType.Name;
            this.uiDictionary.add(key,node);
        }
        return node;
    }

    public async getSingleUIAsync(uiType:UIType){ 
        let key = uiType.Identifier;
        let prefab = await ResourceCache.Instance.loadRes(uiType.Path,true);
        if(prefab==null){
            console.error("prefab not load:",uiType.Path);
            return null;
        }
        let node = cc.instantiate(prefab) as cc.Node;
        node.setParent(this.canvas);
        node.name = uiType.Name;
        this.uiDictionary.add(key,node);
        return node;
    }
    public init(uiRoot:cc.Node){
        this.canvas = uiRoot;
        this.underUIRootNode = new cc.Node('under_ui_root');
        this.underUIRootNode.setParent(this.canvas);
        let wg = this.underUIRootNode.addComponent(cc.Widget);
        wg.isAlignTop = wg.isAlignLeft=wg.isAlignRight = wg.isAbsoluteBottom = true;
        wg.top =wg.left=wg.right=wg.bottom = 0;
        this.underUIRootNode.setPosition(cc.Vec2.ZERO);
        ContextManager.Instance.clear();
        this.uiDictionary.clear();
    }

    private onSceneLoadEnd(){
        this.underUIRootNode.setSiblingIndex(this.canvas.childrenCount);
    }
}