import { DebugHelper } from "../../Helper/DebugHelper";
import { ResourceManager } from "../Pool/ResourceManager";
import { LoopScrollViewItem } from "./LoopScrollViewItem";

/*
*Create By George 2018-11-08 21:57:01
1,填充顺序，从上到下，从左到右
*/
const { ccclass, property } = cc._decorator;

export enum LoopScrollViewType {
    Verticle,
    Horizontal,
}
@ccclass
export class LoopScrollView extends cc.ScrollView {
    @property({
        type: cc.Enum(LoopScrollViewType),
        serializable: true,
        displayName: '滚动类型'
    })
    private viewType: LoopScrollViewType = LoopScrollViewType.Verticle;

    @property({
        type: cc.Integer,
        displayName: '总数'
    })
    private totalCount: number = 0;

    @property({
        type: cc.Integer,
        displayName: '预加载距离'
    })
    private preloadThreshold: number = 0;

    @property({
        displayName: '元素间隔'
    })
    private spacing: cc.Vec2 = cc.v2(0, 0);

    @property({
        displayName: '整体区域内部上下留白'
    })
    private vBlank: cc.Vec2 = cc.v2(0, 0);

    @property({
        displayName: '整体区域内部左右留白'
    })
    private hBlank: cc.Vec2 = cc.v2(0, 0);

    @property({
        displayName: '元素大小'
    })
    private itemSize: cc.Vec2 = cc.v2(0, 0);

    @property({
        type: cc.Integer,
        displayName: '并列元素个数'
    })
    private itemCountPerUnit: number = 1;

    @property({
        type: cc.Node,
        displayName: '预制物体'
    })
    private itemTemplate: cc.Node = null;

    private viewBoundRect: cc.Rect;

    private itemArray: Array<LoopScrollViewItem>;

    get ItemArray() {
        return this.itemArray;
    }
    /// <summary>
    /// 加上元素上下左右留白的大小
    /// </summary>
    private cellSize: cc.Vec2;

    private lastPosition: number = 0;

    private startPositionX: number = 0;

    private startPositionY: number = 0;

    onLoad() {
        // this.init(100);
    }
    public init(totalCount: number) {
        this.itemArray = new Array<LoopScrollViewItem>();
        let eventHandler = new cc.Component.EventHandler();
        eventHandler.target = this.node;
        eventHandler.component = 'LoopScrollView';
        eventHandler.handler = 'onScroll';
        eventHandler.customEventData = 'scrolling';
        this.scrollEvents.push(eventHandler);
        this.viewBoundRect = this.node.getBoundingBox();
        this.totalCount = totalCount;
        this.fillContent();
    }
    public refreshCount(totalCount: number) {
        this.totalCount = totalCount;
        this.fillContentRefresh();
    }

    public refill(totalCount: number) {
        for (let i = 0; i < this.itemArray.length; i++) {
            ResourceManager.Instance.return(this.itemArray[i].node);
        }
        this.itemArray.length = 0;
        this.totalCount = totalCount;
        this.fillContent();
    }

    public onScroll(scrollview, eventType, customEventData) {
        if (eventType == cc.ScrollView.EventType.SCROLLING) {
            if (this.viewType == LoopScrollViewType.Verticle) {
                let isDown = this.content.y < this.lastPosition;
                for (let i = 0; i < this.itemArray.length; i++) {
                    let item = this.itemArray[i];
                    let p = this.getPositionInView(item.node);
                    if (isDown) {
                        if (p.y < this.viewBoundRect.yMin - this.preloadThreshold) {
                            let preIndex = i == this.itemArray.length - 1 ? 0 : i + 1;
                            let preItem = this.itemArray[preIndex];
                            if (preItem.Id - 1 >= 0) {
                                item.node.setPosition(this.getPositionVertical(preItem.Id - 1));
                                item.updateItem(preItem.Id - 1);
                            }
                        }
                    } else {
                        if (p.y > this.viewBoundRect.yMax + this.preloadThreshold) {
                            let preIndex = i == 0 ? this.itemArray.length - 1 : i - 1;
                            let preItem = this.itemArray[preIndex];
                            if (preItem.Id + 1 < this.totalCount) {
                                item.node.setPosition(this.getPositionVertical(preItem.Id + 1));
                                item.updateItem(preItem.Id + 1);
                            }
                        }
                    }
                }
                this.lastPosition = this.content.position.y;
            } else {
                let isLeft = this.content.x < this.lastPosition;
                for (let i = 0; i < this.itemArray.length; i++) {
                    let item = this.itemArray[i];
                    let p = this.getPositionInView(item.node);
                    if (isLeft) {
                        if (p.x < this.viewBoundRect.xMin - this.preloadThreshold) {
                            let preIndex = i == 0 ? this.itemArray.length - 1 : i - 1;
                            let preItem = this.itemArray[preIndex];
                            if (preItem.Id + 1 < this.totalCount) {
                                item.node.setPosition(this.getPositionHorizontal(preItem.Id + 1));
                                item.updateItem(preItem.Id + 1);
                            }
                        }
                    } else {
                        if (p.x > this.viewBoundRect.xMax + this.preloadThreshold) {
                            let preIndex = i == this.itemArray.length - 1 ? 0 : i + 1;
                            let preItem = this.itemArray[preIndex];
                            if (preItem.Id - 1 >= 0) {
                                item.node.setPosition(this.getPositionHorizontal(preItem.Id - 1));
                                item.updateItem(preItem.Id - 1);
                            }
                        }
                    }
                }
                this.lastPosition = this.content.position.x;
            }
        }
    }
    private getPositionInView(item: cc.Node) {
        let wp = this.content.convertToWorldSpaceAR(item.position);
        return this.node.convertToNodeSpaceAR(wp);
    }

    private fillContent() {
        let itemCountActual = 0;
        this.cellSize = cc.v2(this.itemSize.x + this.spacing.x, this.itemSize.y + this.spacing.y);
        switch (this.viewType) {
            case LoopScrollViewType.Verticle:
                this.vertical = true;
                this.horizontal = false;
                this.content.height = Math.ceil(this.totalCount / this.itemCountPerUnit) * this.cellSize.y + this.vBlank.x + this.vBlank.y;
                this.content.width = this.itemCountPerUnit * this.cellSize.x + this.hBlank.x + this.hBlank.y;
                itemCountActual = Math.ceil((this.viewBoundRect.height + this.preloadThreshold * 2) / this.cellSize.y) * this.itemCountPerUnit;
                itemCountActual = Math.min(this.totalCount, itemCountActual);
                this.startPositionX = -this.content.width / 2 + this.hBlank.x + this.cellSize.x / 2;
                this.content.setAnchorPoint(0.5, 1);
                this.content.setPosition(0, this.viewBoundRect.height / 2);
                this.scrollToTop();
                for (let i = 0; i < itemCountActual; i++) {
                    let item = ResourceManager.Instance.get(this.itemTemplate, this.totalCount).getComponent(LoopScrollViewItem);
                    item.node.setParent(this.content);
                    item.node.setPosition(this.getPositionVertical(i));
                    item.updateItem(i);
                    this.itemArray.push(item);
                }
                break;
            case LoopScrollViewType.Horizontal:
                this.vertical = false;
                this.horizontal = true;
                this.content.height = this.itemCountPerUnit * this.cellSize.y + this.hBlank.x + this.hBlank.y;
                this.content.width = Math.ceil(this.totalCount / this.itemCountPerUnit) * this.cellSize.x + this.hBlank.x + this.hBlank.y;
                itemCountActual = Math.ceil((this.viewBoundRect.width + this.preloadThreshold * 2) / this.cellSize.x) * this.itemCountPerUnit;
                itemCountActual = Math.min(this.totalCount, itemCountActual);
                this.startPositionY = -this.content.height / 2 + this.vBlank.y + this.cellSize.y / 2;
                this.content.setAnchorPoint(0, 0.5);
                this.content.setPosition(-this.viewBoundRect.width / 2, 0);
                this.scrollToLeft();
                for (let i = 0; i < itemCountActual; i++) {
                    let item = ResourceManager.Instance.get(this.itemTemplate, this.totalCount).getComponent(LoopScrollViewItem);
                    item.node.setParent(this.content);
                    item.node.setPosition(this.getPositionHorizontal(i));
                    item.updateItem(i);
                    this.itemArray.push(item);
                }
                break;
        }
    }
    private fillContentRefresh() {
        let itemCountActual = 0;
        this.cellSize = cc.v2(this.itemSize.x + this.spacing.x, this.itemSize.y + this.spacing.y);
        switch (this.viewType) {
            case LoopScrollViewType.Verticle:
                this.vertical = true;
                this.horizontal = false;
                this.content.height = Math.ceil(this.totalCount / this.itemCountPerUnit) * this.cellSize.y + this.vBlank.x + this.vBlank.y;
                this.content.width = this.itemCountPerUnit * this.cellSize.x + this.hBlank.x + this.hBlank.y;
                itemCountActual = Math.ceil((this.viewBoundRect.height + this.preloadThreshold * 2) / this.cellSize.y) * this.itemCountPerUnit;
                itemCountActual = Math.min(this.totalCount, itemCountActual);
                this.startPositionX = -this.content.width / 2 + this.hBlank.x + this.cellSize.x / 2;
                this.content.setAnchorPoint(0.5, 1);
                this.content.setPosition(0, this.viewBoundRect.height / 2);
                this.scrollToTop();

                DebugHelper.Log("_itemCountActual" + itemCountActual);
                DebugHelper.Log("_item:" + this.itemArray.length);
                let temp: number = Number(itemCountActual) - Number(this.itemArray.length);
                DebugHelper.Log("temp" + temp);
                for (let i = 0; i < temp; i++) {
                    let item = ResourceManager.Instance.get(this.itemTemplate, this.totalCount).getComponent(LoopScrollViewItem);
                    item.node.setParent(this.content);
                    this.itemArray.push(item);
                }

                DebugHelper.Log("itemCountActual" + itemCountActual);
                DebugHelper.Log("item:" + this.itemArray.length);
                for (let i = 0; i < this.itemArray.length; i++) {
                    this.itemArray[i].node.setPosition(this.getPositionVertical(i));
                    this.itemArray[i].updateItem(i);
                }
                break;
            case LoopScrollViewType.Horizontal:
                this.vertical = false;
                this.horizontal = true;
                this.content.height = this.itemCountPerUnit * this.cellSize.y + this.hBlank.x + this.hBlank.y;
                this.content.width = Math.ceil(this.totalCount / this.itemCountPerUnit) * this.cellSize.x + this.hBlank.x + this.hBlank.y;
                itemCountActual = Math.ceil((this.viewBoundRect.width + this.preloadThreshold * 2) / this.cellSize.x) * this.itemCountPerUnit;
                itemCountActual = Math.min(this.totalCount, itemCountActual);
                this.startPositionY = -this.content.height / 2 + this.vBlank.y + this.cellSize.y / 2;
                this.content.setAnchorPoint(0, 0.5);
                this.content.setPosition(-this.viewBoundRect.width / 2, 0);
                this.scrollToLeft();
                for (let i = 0; i < this.itemCountPerUnit - this.itemArray.length; i++) {
                    let item = ResourceManager.Instance.get(this.itemTemplate, this.totalCount).getComponent(LoopScrollViewItem);
                    item.node.setParent(this.content);
                    this.itemArray.push(item);
                }
                for (let i = 0; i < this.itemArray.length; i++) {
                    this.itemArray[i].node.setPosition(this.getPositionHorizontal(i));
                    this.itemArray[i].updateItem(i);
                }
                break;
        }
    }
    private getPositionVertical(index: number) {
        return cc.v2(this.startPositionX + (index % this.itemCountPerUnit) * this.cellSize.x, -this.vBlank.x - (Math.floor(index / this.itemCountPerUnit) + 0.5) * this.cellSize.y);
    }

    private getPositionHorizontal(index: number) {
        return cc.v2(this.hBlank.x + (Math.floor(index / this.itemCountPerUnit) + 0.5) * this.cellSize.x, this.startPositionY + (index % this.itemCountPerUnit) * this.cellSize.y);
    }

    public refreshAll() {
        DebugHelper.Log("11111");
        for (let i = 0; i < this.itemArray.length; i++) {
            this.itemArray[i].updateItem(i);
        }
    }
    public LocationCurrent(index: number) {
        let temp;
        if (index - 2 >= 0) {
            temp = index - 2;
        }
        else {
            temp = 0;
        }
        this.content.position = cc.v3(0, (-this.getPositionVertical(temp).y) - 111);
        for (let i = 0; i < this.itemArray.length; i++) {
            this.itemArray[i].node.setPosition(this.getPositionVertical(i + temp));
            this.itemArray[i].updateItem(i + temp);
        }
    }
}