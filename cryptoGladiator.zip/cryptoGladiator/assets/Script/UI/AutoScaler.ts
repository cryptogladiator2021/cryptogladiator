import { EventManager, EventType } from "../Event/EventManager";

/*
*Create By George 2019-01-06 13:28:24
*/
const {ccclass, property} = cc._decorator;


@ccclass
export class AutoScaler extends cc.Component{
    private upRatio=[16/9,1];
    private downRatio = [4/3,0.75];
    private scaleFractor:number;

    onLoad(){
        this.scaleFractor = (this.upRatio[1]-this.downRatio[1])/(this.upRatio[0]-this.downRatio[0]);
        if(!CC_JSB&&EventManager.Instance!=null){
            EventManager.Instance.addListener(EventType.WINDOW_RESIZE,this.resize,this);
        }
        this.resize();
    }
    onDestroy(){
        if(!CC_JSB&&EventManager.Instance!=null){
            EventManager.Instance.removeListener(EventType.WINDOW_RESIZE,this.resize,this);
        }
    }
    private resize(){
        let ratio = cc.winSize.height/cc.winSize.width;
        let scale = (ratio-this.downRatio[0])*this.scaleFractor+this.downRatio[1];
        this.node.scale = cc.misc.clampf(scale,0.3,1);
    }
}