import { EventManager, EventType } from "../Event/EventManager";
import { Locallization } from "../Locallization/Locallization";

/*
*Create By George 2019-01-06 13:28:24
*/
const { ccclass, property } = cc._decorator;


@ccclass
export class LocalTxt extends cc.Component {
    @property(cc.String)
    private key: string = "";

    public SetKey(key: string) {
        this.key = key;
        this.Refresh();
    }

    onEnable() {
        this.Refresh();
        EventManager.Instance.addListener(EventType.LANGUAGE_CHANGE, this.Refresh, this);
    }

    Refresh() {
        let lable = this.getComponent(cc.Label);
        lable.string = Locallization.Instance.getText(this.key);
    }
    onDisable() {
        EventManager.Instance.removeListener(EventType.LANGUAGE_CHANGE, this.Refresh, this);
    }
}