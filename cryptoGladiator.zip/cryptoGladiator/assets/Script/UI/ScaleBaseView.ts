/*
* Created by George on 2018/10/21
*/
import { BaseContext } from "./BaseContext";
import { ContextManager } from "./ContextManager";
import { AutoScaler } from "./AutoScaler";
import { Utility } from "../Util/Utility";
import { BaseView } from "./BaseView";

const { ccclass, property } = cc._decorator;

@ccclass
export class ScaleBaseView extends BaseView {
    bg: cc.Node;
    public initOnce(context: BaseContext) {
        super.initOnce(context);
        this.bg = this.node.getDeepChildByPath("bg");
        if (this.bg != null) {
            this.bg.scale = 0;
            this.bg.color.setA(0);
            var scTo = cc.scaleTo(0.3, 1).easing(cc.easeBackOut());
            this.bg.runAction(scTo);
            var alphaTo = cc.fadeIn(0.3)
            this.bg.runAction(alphaTo);
        }
    }
    public onEnter(context: BaseContext) {
        super.onEnter(context);
    }
    public onExit(context: BaseContext, callBack?: () => void) {
        super.onExit(context);
        if (this.bg != null) {
            this.bg.scale = 1;
            this.bg.color.setA(1);
            var alphaTo = cc.fadeOut(0.2)
            this.bg.runAction(alphaTo);
            var scTo = cc.scaleTo(0.2, 0.8).easing(cc.easeBackIn());
            this.bg.runAction(cc.sequence(scTo, cc.callFunc(() => {
                console.log(callBack);
                if (callBack)
                    callBack();
            }, this)));
        }
    }
    public onPause(context: BaseContext) {
        super.onPause(context);
    }
    public onResume(context: BaseContext) {
        super.onResume(context);
    }

}