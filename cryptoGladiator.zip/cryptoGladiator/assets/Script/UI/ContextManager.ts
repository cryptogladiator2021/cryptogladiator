/*
* Created by George on 2018/10/21
*/
import {Stack} from "../Util/Utility";
import {BaseContext} from "./BaseContext";
import {BaseView} from "./BaseView";
import {UIManager} from "./UIManager";
import { ResourceManager } from "../Pool/ResourceManager";
import { SceneLoader } from "../Core/SceneLoader";

export class ContextManager {
    
    private static instance:ContextManager = null;

    static get Instance(){
        if(this.instance != null){
            return this.instance;
        }else{
            return this.instance = new ContextManager();
        }
    }

    private constructor(){}
    
    private contextStack:Stack<BaseContext> = new Stack<BaseContext>();

    public async push(nextContext:BaseContext,isMultiple:boolean = false){
        if(SceneLoader.Instance.IsLoading) return;
        if(!isMultiple){
            for (let i = 0; i < this.contextStack.size(); i++) {
                if(this.contextStack._store[i].ViewType.Path==nextContext.ViewType.Path) return;
            }
        }
        let nextViewNode:any = UIManager.Instance.getSingleUISync(nextContext.ViewType);
        if(nextViewNode==null){
            let viewLoadingNode = await ResourceManager.Instance.getFromResource('prefab/common/view_loading',1,false);
            viewLoadingNode.setParent(UIManager.Instance.Canvas);
            nextViewNode = await UIManager.Instance.getSingleUIAsync(nextContext.ViewType);
            ResourceManager.Instance.return(viewLoadingNode);
            if(nextViewNode ==null) return;
        }
        if(this.contextStack.size()!=0){
            let curContext:BaseContext = this.contextStack.peek();
            let currentViewNode:any = UIManager.Instance.getSingleUISync(curContext.ViewType);
            let curView:BaseView = currentViewNode.getComponent(BaseView);
            curView.onPause(curContext);
        }
        this.contextStack.push(nextContext);
        let nextView:BaseView = nextViewNode.getComponent(BaseView);
        nextView.onEnter(nextContext);
    }
    public pop(){
        let lastView:BaseView;
        let lastContext:BaseContext;
        if(this.contextStack.size()!=0){
            let curContext = this.contextStack.peek();
            this.contextStack.pop();
            if(this.contextStack.size()!=0){
                lastContext = this.contextStack.peek();
                let lastViewNode:any = UIManager.Instance.getSingleUISync(lastContext.ViewType);
                lastView = lastViewNode.getComponent(BaseView);
            }
            let curViewNode:any = UIManager.Instance.getSingleUISync(curContext.ViewType);
            let curView = curViewNode.getComponent(BaseView);
            curView.onExit(curContext);
        }
        if(lastView!=undefined){
            lastView.onResume(lastContext);
        }
    }

    public clear(){
        this.contextStack.clear();
    }

    public hasUIShowUp(){
        return this.contextStack.size()>0;
    }
}