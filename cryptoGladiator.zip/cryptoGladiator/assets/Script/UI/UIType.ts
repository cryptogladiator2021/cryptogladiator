/*
* Created by George on 2018/10/20
*/

export class UIType {
    public static globalId = 0;

    private path:string;

    get Path(){
        return this.path;
    }

    private name:string;

    get Name(){
        return this.name;
    }

    private prefab:cc.Prefab;

    get Prefab(){
        return this.prefab;
    }

    private identifier:string;
    get Identifier(){
        return this.identifier;
    }
    
    constructor(path:string,prefab:cc.Prefab =null){
        
        if(prefab==null) {

            this.path = path;

            this.name = path.substr(path.lastIndexOf('/') + 1);

            this.prefab = null;
        }else{
            this.name = prefab.name;

            this.path = this.name;

            this.prefab = prefab;
        }

        this.identifier = this.path+"_"+UIType.globalId++;
    }
}