
const {ccclass, property} = cc._decorator;

@ccclass
export default class CanvasScale extends cc.Component {

    private canvas:cc.Canvas;
    onLoad () {
        this.canvas = this.node.getComponent(cc.Canvas);
        this.Init();

    }

    start () {
        this.Event(this.Click)
        

    }
    private Click(){

    }
    private Init(){
        var b = cc.director.getWinSizeInPixels();
        var screenScale = b.height/b.width;
        var canvasScale = this.canvas.designResolution.height/this.canvas.designResolution.width;
        //cc.log("屏幕尺寸"+screenScale);
        //cc.log("画布尺寸"+canvasScale);
        if(screenScale>canvasScale){
            this.canvas.fitHeight = false;
            this.canvas.fitWidth =true;
        }
        else{
            this.canvas.fitHeight = true;
            this.canvas.fitWidth =false;
        }
    }
    private Event(cb:()=>void){

    }
    
}

