/*
* Created by George on 2018/10/22
*/
import audioEngine = cc.audioEngine;
import {Dictionary} from "../Util/Utility";
import AudioClip = cc.AudioClip;

const {ccclass, property} = cc._decorator;
 
@ccclass
export class AudioManager extends cc.Component {
    private MAX_TONE_FRAME:number=6;
 
    public static instance:AudioManager;

    private frameNumber:number;

    private toneAudioClipDictionary:Dictionary<cc.AudioClip> = new Dictionary<cc.AudioClip>();

    private musicAudioClipDictionary:Dictionary<cc.AudioClip> = new Dictionary<cc.AudioClip>();

    private currentMusicName:string;
    get CurrentMusicName(){
        return this.currentMusicName;
    }
    private playedToneCount:number =0;

    onLoad(){
        this.frameNumber = 0;

        AudioManager.instance = this;

        this.initSoundStatus();
    }

    private loadToneFromResource(name:string){
        return new Promise((resolve,reject)=>{
            cc.loader.loadRes('sound/tone/'+name,cc.AudioClip,(err,res:cc.AudioClip)=>{
                if(err){
                    cc.error(err.message || err);
                    resolve(null);
                }else{
                    //console.log("tone name:",name);
                    this.toneAudioClipDictionary.add(name,res);
                    resolve(res);
                }
            });
        })
    }
    private loadMusicFromResource(name:string){
        return new Promise((resolve,reject)=>{
            cc.loader.loadRes('sound/music/'+name,cc.AudioClip,(err,res:cc.AudioClip)=>{
                if(err){
                    cc.error(err.message || err);
                    resolve(null);
                }else{
                    this.musicAudioClipDictionary.add(name,res);
                    resolve(res);
                }
            });
        })
    }
    public  preloadToneClips(cb:(c,t)=>any){
        return new Promise((resolve,reject)=>{
            cc.loader.loadResDir('sound/tone',cc.AudioClip,cb, (err,audioClips,urls)=>{
                if(err){
                    cc.error(err.message || err);
                }else{
                    audioClips.forEach(e=>{
                        this.toneAudioClipDictionary.add(e.name,e);
                    });
                }
                resolve(audioClips);
            });
        })
    }

    update(){
        if(this.frameNumber++>=this.MAX_TONE_FRAME&&this.playedToneCount>0){
            this.frameNumber=0;
            this.playedToneCount = 0;
            let toneArray = this.toneAudioClipDictionary.values();
            for(let i=0;i<toneArray.length;i++){
                let clip = toneArray[i];
                if(clip['played']==true){
                    cc.audioEngine.playEffect(clip,false);
                }
                clip['played'] = false;
            }
        }
    }
    public async playTone(toneName:string){
        if(!this.soundStatus){
            return;
        }
        if(!this.toneAudioClipDictionary.containsKey(toneName)){
            await this.loadToneFromResource(toneName);
        }

        let audioClip = this.toneAudioClipDictionary[toneName];
        audioClip['played']=true;
        this.playedToneCount++;
    }

    public async playMusic(musicName:string){
        this.currentMusicName = musicName;
        if(!this.musicStatus){
            return;
        }
        if(!this.musicAudioClipDictionary.containsKey(musicName)){
            await this.loadMusicFromResource(musicName);
        }
        let audioClip = this.musicAudioClipDictionary[musicName];
        cc.audioEngine.playMusic(audioClip,true);
    }

    public stopMusic(){
        if(!this.musicStatus){
            return;
        }
        cc.audioEngine.stopMusic();
    }
    public resumeMusic(){
        if(this.currentMusicName ==null){
            return;
        }
        if(!this.musicAudioClipDictionary.containsKey(this.currentMusicName)){
            console.log('音乐不存在:'+this.currentMusicName);
            return;
        }

        let ac = this.musicAudioClipDictionary[this.currentMusicName];
        
        cc.audioEngine.playMusic(ac,true);
    }

    public addToneAndMusic(tones:cc.AudioClip[],musics:cc.AudioClip[]){
        let toneArray:string[] = [];
        let musicArray:string[] = [];
        tones.forEach(e => {
            this.toneAudioClipDictionary.add(e.name,e);
            toneArray.push(e.name);
        });
        musics.forEach(e => {
            this.musicAudioClipDictionary.add(e.name,e);
            musicArray.push(e.name);
        });
        return [toneArray,musicArray];
    }
    public removeToneAndMusic(tones:string[],musics:string[]){
        tones.forEach(e => {
            this.toneAudioClipDictionary.remove(e);
        });
        musics.forEach(e => {
            this.musicAudioClipDictionary.remove(e);
        });
    }
    private initSoundStatus(){
        let ss = cc.sys.localStorage.getItem('sound');
        let ms = cc.sys.localStorage.getItem('music');

        if(!ss){
            cc.sys.localStorage.setItem('sound','1');
            this.soundStatus = true;
        }else{
            this.soundStatus = ss=='0'?false:true;
        }

        if(!ms){
            cc.sys.localStorage.setItem('music','1');
            this.musicStatus = true;
        }else{
            this.musicStatus = ms=='0'?false:true;
        }
    }

    private soundStatus:boolean;

    private musicStatus:boolean;

    get SoundStatus(){
        return this.soundStatus;
    }

    set SoundStatus(value){
        this.soundStatus = value;

        if(this.soundStatus){
            cc.sys.localStorage.setItem('sound','1');
        }else{
            cc.sys.localStorage.setItem('sound','0');
        }
    }
    get MusicStatus(){
        return this.musicStatus;
    }

    set MusicStatus(value){
        this.musicStatus = value;

        if(this.musicStatus){
            cc.sys.localStorage.setItem('music','1');
        }else{
            cc.sys.localStorage.setItem('music','0')
        }
    }
}